#include <inttypes.h>
#include "base_device.h"

base_device::base_device ():
    current_device_write_value(0)
{
    
}

void base_device::pause()      
{
}

void base_device::stop()      
{
}

void base_device::resume()      
{
}


